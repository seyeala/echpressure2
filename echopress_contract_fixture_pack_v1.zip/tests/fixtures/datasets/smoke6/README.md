# smoke6 synthetic fixture dataset

Tiny deterministic fixture dataset for CI contract/data tests.

It contains 6 synthetic `.npz` waveform files with:
- one channel, `channels` shape `(6000, 1)`
- `timestamps` shape `(6000,)`
- five primary peaks per file: `500, 1500, 2500, 3500, 4500`
- four complete peak-to-peak windows per file
- three secondary echoes per complete window at offsets `120, 260, 500`
- pressure encoded in the filename and in expected CSV metadata

This is not production data. It is safe to commit.
